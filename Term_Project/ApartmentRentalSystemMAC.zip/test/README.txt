# MAC Distribution of Apartment Rental System
# By Team6.pro

##############    STEPS       ##############

1) After Downloading unzip folder "test"
2) Place folder anywhere on Desktop
3) Open Folder
4) Click to open the file ApartmentRentalSystem.exe